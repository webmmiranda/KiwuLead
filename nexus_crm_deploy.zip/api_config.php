<?php
// Configuración de Base de Datos
// Este archivo debe ser ignorado por git para seguridad
define('DB_HOST', 'localhost');
define('DB_NAME', 'nexus_crm_local');
define('DB_USER', 'root');
define('DB_PASS', '');

// Security Keys
define('JWT_SECRET', 'nexus_crm_secret_key_change_in_production_992834');
